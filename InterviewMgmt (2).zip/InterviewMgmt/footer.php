<style>
    footer{
        display: flex;
        justify-content: center;
        margin-top:40px;
        position:relative;
        bottom:0;
        font-size: 15px;

    }
    footer div span{

    }
    </style>
<footer>
    <div>
        <span>Copyright 2023 &copy; <strong>All rights Reserved</strong></span>
    </div>
</footer>