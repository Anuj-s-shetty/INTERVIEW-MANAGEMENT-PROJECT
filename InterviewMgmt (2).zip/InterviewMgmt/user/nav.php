<style>
  .navbar-inverse .navbar-nav > li > a{
    color: #000;
    padding: 20px 85px;
  }
  .navbar-inverse .navbar-nav > li > a:hover{
  color: #0938ee;
  }
  .navbar-inverse .navbar-brand {
  color: #000;
}
.navbar-inverse .navbar-brand:hover {
  color:  #000;
}
.navbar-inverse {
  background-color: #02f3ff;
  border-color: #ff41a3;
}

  </style>
<nav class="navbar navbar-inverse" style="width: 75% !important; margin: auto; ">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="">Interview Management  System</a>
    </div>
    <ul class="nav navbar-nav">
    <!-- class="active" -->
      <!-- <li ><a href="viewCandidate.php">Home</a></li> -->
      <li><a href=home.php>Home</a></li>
      <li><a href=addCandidate.php>Add New Candidate</a></li>
      <li><a href=about.php>About Us</a></li>

      <!-- <li><a href="addQuestion.php">Add New Question</a></li>
      <li><a href="viewCandidate.php">View Candidates</a></li>
      <li><a href="viewQuestions.php">View Questions</a></li> -->
    </ul>
  </div>
</nav>
